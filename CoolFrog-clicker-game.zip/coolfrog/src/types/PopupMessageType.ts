export type PopupMessageType = {
  id: number;
  title: string;
  text: string;
  image: string;
  button_text: string;
  button_link: string;
};
